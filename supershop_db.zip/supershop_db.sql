-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2024 at 06:04 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supershop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `Company_ID` int(11) NOT NULL,
  `Company_Name` varchar(20) NOT NULL,
  `Entry_Date` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`Company_ID`, `Company_Name`, `Entry_Date`) VALUES
(2435, '', ''),
(4001, 'Yellow', '2024-06-13'),
(4002, 'Easy', '2024-06-14'),
(4003, 'Bata', '2024-06-21'),
(4009, 'Apex', '2024-06-30'),
(4011, 'Care', '2024-07-06'),
(4050, 'Event Solution BD', '2024-06-21'),
(4085, 'Partho EnterPrice', '2024-07-03'),
(4900, 'LG', '12/12/2023'),
(233223, 'Yellow', '2024-07-27');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `C_ID` int(11) NOT NULL,
  `C_Name` varchar(25) NOT NULL,
  `C_Email` varchar(45) NOT NULL,
  `C_Num` int(11) NOT NULL,
  `C_Address` varchar(25) DEFAULT NULL,
  `C_Grade` varchar(10) DEFAULT NULL,
  `E_ID` int(11) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `E_ID` int(11) NOT NULL,
  `E_Name` varchar(30) NOT NULL,
  `E_Rank` varchar(20) NOT NULL,
  `E_Num` int(14) NOT NULL,
  `E_City` varchar(20) NOT NULL,
  `E_Salary` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`E_ID`, `E_Name`, `E_Rank`, `E_Num`, `E_City`, `E_Salary`) VALUES
(1, 'Bappy Deb Nath', 'Manager', 1797127296, 'Dhaka', 95000),
(222, 'Bappy Deb Nath', 'Manager', 657568, 'Dhaka', 95000);

-- --------------------------------------------------------

--
-- Table structure for table `ordes`
--

CREATE TABLE `ordes` (
  `O_ID` int(11) NOT NULL,
  `O_Amount` varchar(25) NOT NULL,
  `O_Date` varchar(45) NOT NULL,
  `E_ID` int(11) DEFAULT NULL,
  `C_ID` int(11) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `producersup`
--

CREATE TABLE `producersup` (
  `P_ID` int(10) NOT NULL,
  `CName` varchar(35) NOT NULL,
  `TLN` int(60) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Zip` int(10) NOT NULL,
  `Files` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `producersup`
--

INSERT INTO `producersup` (`P_ID`, `CName`, `TLN`, `City`, `Zip`, `Files`) VALUES
(2, 'Yellow', 443, 'Dhaka', 1207, 'ubzwydz.pdf'),
(44, 'Easy', 2147483647, 'Dhaka', 1207, 'nid-3311368298.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `P_ID` int(10) NOT NULL,
  `P_Name` varchar(20) NOT NULL,
  `P_Catagory` varchar(20) NOT NULL,
  `C_ID` int(20) NOT NULL,
  `C_Name` varchar(20) NOT NULL,
  `Price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`P_ID`, `P_Name`, `P_Catagory`, `C_ID`, `C_Name`, `Price`) VALUES
(1, 'Apple', '', 4100, 'bDN', 180),
(3, 'Panjabi', '', 4900, 'Coka Cola', 50),
(5, 'Shirt', '', 4001, 'Yellow', 1800),
(13, 'pen', 'Educational', 4444, 'Matardor Hi School', 5),
(111, 'Panjabi', 'Fasion', 4001, 'Yellow', 2000),
(113, 'pen', 'Educational', 4444, 'Matardor Hi School', 5),
(120, 'Shirt', 'Fasion', 4400, 'Easy', 1200);

-- --------------------------------------------------------

--
-- Table structure for table `product_img`
--

CREATE TABLE `product_img` (
  `IG_ID` int(10) UNSIGNED NOT NULL,
  `IG_Title` varchar(100) NOT NULL,
  `IG_CName` varchar(60) NOT NULL,
  `IG_Price` int(12) NOT NULL,
  `IG_Name` varchar(250) NOT NULL,
  `IG_Feature` varchar(20) NOT NULL,
  `IG_Action` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_img`
--

INSERT INTO `product_img` (`IG_ID`, `IG_Title`, `IG_CName`, `IG_Price`, `IG_Name`, `IG_Feature`, `IG_Action`) VALUES
(5, 'New Arrivels', 'Yellow', 222222, '3-8d3269dc3d.jpg', 'Yes', 'NO'),
(6, 'New Arrivels', 'Yellow', 222222, '3-8d3269dc3d.jpg', 'Yes', 'NO'),
(7, 'New Arrivels', 'Yellow', 222222, '3-8d3269dc3d.jpg', 'Yes', 'NO'),
(8, 'New Arrivels', 'Yellow', 222222, '3-8d3269dc3d.jpg', 'Yes', 'NO'),
(9, 'New Arrivels', 'Yellow', 222222, '3-8d3269dc3d.jpg', 'Yes', 'NO'),
(10, 'New Arrivels', 'Yellow', 222222, '3-8d3269dc3d.jpg', 'Yes', 'NO'),
(12, 'New Arrivels', 'Yellow', 1000000, 'Prottoy.jpg', 'Yes', 'NO'),
(13, 'New Arrivels', 'Yellow', 2300, 'ERD.jpg', 'No', 'NO'),
(14, 'New Arrivels', 'Yellow', 2300, 'ERD.jpg', 'No', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `prosignup`
--

CREATE TABLE `prosignup` (
  `ID` int(11) NOT NULL,
  `CName` varchar(35) NOT NULL,
  `PassWord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prosignup`
--

INSERT INTO `prosignup` (`ID`, `CName`, `PassWord`) VALUES
(4, 'Yellow', '$2y$10$mctTYjgAQNx3jhK3j1vgauB1UEiwb9wTS9.V7VfJzNG75Bsc20aDG'),
(9, 'Easy', '$2y$10$jyni5ULnxkfnrrRCPIWsLerFeb6oNiKXpAFjz6EnrurlgOmh0XoiS');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `U_ID` int(11) NOT NULL,
  `U_FName` varchar(20) NOT NULL,
  `U_Lname` varchar(20) NOT NULL,
  `U_Email` varchar(30) NOT NULL,
  `U_Address` varchar(30) NOT NULL,
  `U_PNum` int(12) NOT NULL,
  `U_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`U_ID`, `U_FName`, `U_Lname`, `U_Email`, `U_Address`, `U_PNum`, `U_password`) VALUES
(1, 'Bappy', 'Nath', 'bappy.cse.20210204074@gmail.co', 'Dhaka,Bangladesh', 1973336948, 'bappy1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`Company_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`C_ID`),
  ADD KEY `E_ID` (`E_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`E_ID`);

--
-- Indexes for table `ordes`
--
ALTER TABLE `ordes`
  ADD PRIMARY KEY (`O_ID`),
  ADD KEY `E_ID` (`E_ID`),
  ADD KEY `C_ID` (`C_ID`);

--
-- Indexes for table `producersup`
--
ALTER TABLE `producersup`
  ADD PRIMARY KEY (`P_ID`),
  ADD UNIQUE KEY `CName` (`CName`),
  ADD UNIQUE KEY `TLN` (`TLN`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`P_ID`);

--
-- Indexes for table `product_img`
--
ALTER TABLE `product_img`
  ADD PRIMARY KEY (`IG_ID`);

--
-- Indexes for table `prosignup`
--
ALTER TABLE `prosignup`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `CName` (`CName`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`U_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `E_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;

--
-- AUTO_INCREMENT for table `ordes`
--
ALTER TABLE `ordes`
  MODIFY `O_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_img`
--
ALTER TABLE `product_img`
  MODIFY `IG_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `prosignup`
--
ALTER TABLE `prosignup`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `U_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`E_ID`) REFERENCES `employee` (`E_ID`);

--
-- Constraints for table `ordes`
--
ALTER TABLE `ordes`
  ADD CONSTRAINT `ordes_ibfk_1` FOREIGN KEY (`E_ID`) REFERENCES `employee` (`E_ID`),
  ADD CONSTRAINT `ordes_ibfk_2` FOREIGN KEY (`C_ID`) REFERENCES `customer` (`C_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
